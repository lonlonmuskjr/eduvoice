"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Save } from "lucide-react"
import Link from "next/link"

export default function SettingsPage() {
  const [humeApiKey, setHumeApiKey] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()

  // Load saved API key on component mount
  useEffect(() => {
    const savedApiKey = localStorage.getItem("humeApiKey") || ""
    setHumeApiKey(savedApiKey)
  }, [])

  const saveSettings = async () => {
    setIsSaving(true)

    try {
      // Save API key to localStorage for client-side access
      localStorage.setItem("humeApiKey", humeApiKey)

      // In a real application, you would also save this securely on the server
      // For demo purposes, we're just using localStorage

      toast({
        title: "Settings saved",
        description: "Your Hume API key has been saved successfully.",
      })
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your settings.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>
      </div>

      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Settings</h1>

        <Card>
          <CardHeader>
            <CardTitle>API Keys</CardTitle>
            <CardDescription>Configure your API keys for external services</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="humeApiKey">Hume API Key</Label>
              <Input
                id="humeApiKey"
                type="password"
                value={humeApiKey}
                onChange={(e) => setHumeApiKey(e.target.value)}
                placeholder="Enter your Hume API key"
              />
              <p className="text-sm text-muted-foreground">
                Your Hume API key is used for voice interactions and emotional intelligence features. Get your API key
                from the{" "}
                <a
                  href="https://hume.ai/dashboard"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Hume Dashboard
                </a>
                .
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={saveSettings} disabled={isSaving} className="flex items-center">
              {isSaving ? (
                "Saving..."
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Settings
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

