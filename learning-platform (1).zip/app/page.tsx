import { Button } from "@/components/ui/button"
import Link from "next/link"
import { HeroSection } from "@/components/hero-section"
import { FeatureSection } from "@/components/feature-section"
import { CourseShowcase } from "@/components/course-showcase"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <HeroSection />
      <FeatureSection />
      <CourseShowcase />

      <section className="py-16 text-center">
        <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Learning Experience?</h2>
        <div className="flex justify-center gap-4">
          <Button asChild size="lg">
            <Link href="/courses">Explore Courses</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/create">Create a Course</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

