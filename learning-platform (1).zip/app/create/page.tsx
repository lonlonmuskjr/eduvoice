"use client"

import { useState, useEffect } from "react"
import { CourseCreator } from "@/components/course-creator"
import { Button } from "@/components/ui/button"
import { Mic, MicOff, Settings } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from "next/link"

export default function CreateCoursePage() {
  const [isVoiceMode, setIsVoiceMode] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState("details")
  const [humeApiKey, setHumeApiKey] = useState<string | null>(null)
  const [voiceGuide, setVoiceGuide] = useState({
    step: "welcome",
    message:
      "Welcome to the course creation assistant. I'll guide you through creating your course. First, let's research your topic. What would you like to learn more about?",
    responses: [],
  })

  // Load Hume API key on component mount
  useEffect(() => {
    const apiKey = localStorage.getItem("humeApiKey")
    setHumeApiKey(apiKey)
  }, [])

  const toggleVoiceMode = () => {
    if (!humeApiKey) return

    setIsVoiceMode(!isVoiceMode)
    if (!isVoiceMode) {
      // Reset the voice guide when entering voice mode
      setVoiceGuide({
        step: "welcome",
        message:
          "Welcome to the course creation assistant. I'll guide you through creating your course. First, let's research your topic. What would you like to learn more about?",
        responses: [],
      })
    }
  }

  const toggleListening = () => {
    if (!humeApiKey) return

    setIsListening(!isListening)

    if (!isListening) {
      // Simulate voice recognition starting
      setTimeout(() => {
        // Simulate receiving a response after 2 seconds
        simulateVoiceResponse()
      }, 2000)
    }
  }

  const simulateVoiceResponse = () => {
    setIsListening(false)

    // Simulate different responses based on the current step
    let newResponse = ""
    let nextStep = ""
    let nextMessage = ""

    switch (voiceGuide.step) {
      case "welcome":
        newResponse = "I'd like to learn more about artificial intelligence and machine learning."
        nextStep = "research"
        nextMessage =
          "Great topic! Let me search for some information about artificial intelligence and machine learning to help you create your course."
        // Trigger research integration
        setTimeout(() => integrateResearch("artificial intelligence and machine learning"), 1000)
        break
      case "research":
        newResponse = "This research looks helpful. Let's use it to create my course."
        nextStep = "title"
        nextMessage =
          "Now that we have some research, let's start building your course. What would you like to title your course?"
        break
      case "title":
        newResponse = "Introduction to Artificial Intelligence and Machine Learning"
        nextStep = "description"
        nextMessage = "Excellent title! Now, could you provide a brief description of what your course will cover?"
        break
      case "description":
        newResponse =
          "This course will introduce students to the fundamentals of AI and machine learning, covering basic concepts, algorithms, and practical applications."
        nextStep = "category"
        nextMessage =
          "I've captured that description. What category would this course fall under? Technology, Business, Design, or something else?"
        break
      case "category":
        newResponse = "Technology"
        nextStep = "level"
        nextMessage = "And what level is this course designed for? Beginner, Intermediate, Advanced, or All Levels?"
        break
      case "level":
        newResponse = "Beginner"
        nextStep = "modules"
        nextMessage = "Perfect! Now let's structure your course. What modules or sections would you like to include?"
        break
      case "modules":
        newResponse =
          "I'd like to have modules on Introduction to AI, Basic Machine Learning Algorithms, Neural Networks, and Practical Applications."
        nextStep = "complete"
        nextMessage =
          "I've captured your course structure. Your course details have been filled out based on our conversation. You can now review and edit the information in the course creator below, or continue using voice to add more details."
        break
      default:
        newResponse = "I'd like to add more content to the course."
        nextStep = "welcome"
        nextMessage =
          "Sure, you can continue adding content using the course creator below. Would you like me to guide you through another section?"
    }

    // Update the voice guide with the new response and next step
    setVoiceGuide({
      step: nextStep,
      message: nextMessage,
      responses: [
        ...voiceGuide.responses,
        {
          user: newResponse,
          assistant: nextMessage,
        },
      ],
    })
  }

  // Add this function after the simulateVoiceResponse function
  const integrateResearch = (query: string) => {
    // In a real implementation, this would call an API to get research results
    // For demo purposes, we'll simulate research results
    if (query.toLowerCase().includes("artificial intelligence")) {
      setActiveTab("research")
      // Simulate research results appearing
      setTimeout(() => {
        setSearchResults([
          {
            id: "1",
            title: "Introduction to Artificial Intelligence",
            source: "AI Research Journal",
            excerpt:
              "Artificial Intelligence (AI) is a field of computer science that focuses on creating machines capable of intelligent behavior. This article provides an overview of AI concepts, history, and applications.",
            content:
              'Artificial Intelligence (AI) is a field of computer science that focuses on creating machines capable of intelligent behavior. The term was coined in 1956 by John McCarthy, who defined it as "the science and engineering of making intelligent machines."\n\nAI research is highly technical and specialized, divided into subfields that often fail to communicate with each other. These subfields are based on technical considerations, such as particular goals (e.g., "robotics" or "machine learning"), the use of particular tools ("logic" or "neural networks"), or deep philosophical differences.\n\nThe traditional problems of AI research include reasoning, knowledge representation, planning, learning, natural language processing, perception, and the ability to move and manipulate objects. General intelligence is still among the field\'s long-term goals.',
          },
          {
            id: "2",
            title: "Machine Learning Fundamentals",
            source: "Data Science Weekly",
            excerpt:
              "Machine Learning is a subset of AI that provides systems the ability to automatically learn and improve from experience without being explicitly programmed.",
            content:
              "Machine Learning is a subset of Artificial Intelligence that provides systems the ability to automatically learn and improve from experience without being explicitly programmed. It focuses on the development of computer programs that can access data and use it to learn for themselves.\n\nThe process of learning begins with observations or data, such as examples, direct experience, or instruction, in order to look for patterns in data and make better decisions in the future based on the examples that we provide. The primary aim is to allow the computers to learn automatically without human intervention or assistance and adjust actions accordingly.\n\nMachine Learning algorithms are often categorized as supervised (using labeled training data), unsupervised (using unlabeled training data), or reinforcement learning (learning through trial and error with rewards and penalties).",
          },
        ])
      }, 1000)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Create a New Course</h1>
        <div className="flex gap-2">
          {!humeApiKey && (
            <Button asChild variant="outline">
              <Link href="/settings" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Add API Key
              </Link>
            </Button>
          )}
          <Button
            onClick={toggleVoiceMode}
            variant={isVoiceMode ? "default" : "outline"}
            className="flex items-center gap-2"
            disabled={!humeApiKey}
          >
            <Mic className="h-4 w-4" />
            {isVoiceMode ? "Exit Voice Mode" : "Use Voice Assistant"}
          </Button>
        </div>
      </div>

      {!humeApiKey && (
        <Alert className="mb-6">
          <AlertTitle>Hume API Key Required</AlertTitle>
          <AlertDescription>
            To use the voice assistant features, please add your Hume API key in the settings.
            <Link href="/settings" className="ml-1 underline">
              Go to Settings
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {isVoiceMode && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Hume Voice Assistant</CardTitle>
            <CardDescription>I'll guide you through creating your course using voice interaction</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <p className="font-medium">{voiceGuide.message}</p>
              </div>

              {voiceGuide.responses.length > 0 && (
                <div className="space-y-4 max-h-60 overflow-y-auto p-2">
                  {voiceGuide.responses.map((response, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex gap-2 items-start">
                        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
                          Y
                        </div>
                        <div className="flex-1 p-3 bg-primary/10 rounded-lg">{response.user}</div>
                      </div>
                      <div className="flex gap-2 items-start">
                        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground font-bold">
                          H
                        </div>
                        <div className="flex-1 p-3 bg-secondary/10 rounded-lg">{response.assistant}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex justify-center">
                <Button
                  onClick={toggleListening}
                  variant={isListening ? "destructive" : "default"}
                  size="lg"
                  className="rounded-full w-16 h-16 flex items-center justify-center"
                  disabled={!humeApiKey}
                >
                  {isListening ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
                </Button>
              </div>

              {isListening && <div className="text-center text-muted-foreground">Listening... Speak now</div>}
            </div>
          </CardContent>
        </Card>
      )}

      <CourseCreator
        initialData={
          voiceGuide.step === "complete"
            ? {
                title: "Introduction to Artificial Intelligence and Machine Learning",
                description:
                  "This course will introduce students to the fundamentals of AI and machine learning, covering basic concepts, algorithms, and practical applications.",
                category: "technology",
                level: "beginner",
                modules: [
                  {
                    id: "1",
                    title: "Introduction to AI",
                    lessons: [
                      {
                        id: "1",
                        title: "What is Artificial Intelligence?",
                        content: "",
                        type: "text",
                      },
                    ],
                  },
                  {
                    id: "2",
                    title: "Basic Machine Learning Algorithms",
                    lessons: [
                      {
                        id: "2",
                        title: "Supervised Learning",
                        content: "",
                        type: "text",
                      },
                    ],
                  },
                  {
                    id: "3",
                    title: "Neural Networks",
                    lessons: [
                      {
                        id: "3",
                        title: "Introduction to Neural Networks",
                        content: "",
                        type: "text",
                      },
                    ],
                  },
                  {
                    id: "4",
                    title: "Practical Applications",
                    lessons: [
                      {
                        id: "4",
                        title: "Real-world AI Applications",
                        content: "",
                        type: "text",
                      },
                    ],
                  },
                ],
              }
            : undefined
        }
      />
    </div>
  )
}

