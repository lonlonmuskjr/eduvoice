"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, BookOpen, FileText, Plus } from "lucide-react"

interface ResearchAssistantProps {
  onAddToLesson: (content: string) => void
}

export function ResearchAssistant({ onAddToLesson }: ResearchAssistantProps) {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [selectedContent, setSelectedContent] = useState("")

  const handleSearch = () => {
    if (!query.trim()) return

    setIsSearching(true)

    // Simulate search results
    setTimeout(() => {
      setSearchResults([
        {
          id: "1",
          title: "Introduction to Artificial Intelligence",
          source: "AI Research Journal",
          excerpt:
            "Artificial Intelligence (AI) is a field of computer science that focuses on creating machines capable of intelligent behavior. This article provides an overview of AI concepts, history, and applications.",
          content:
            'Artificial Intelligence (AI) is a field of computer science that focuses on creating machines capable of intelligent behavior. The term was coined in 1956 by John McCarthy, who defined it as "the science and engineering of making intelligent machines."\n\nAI research is highly technical and specialized, divided into subfields that often fail to communicate with each other. These subfields are based on technical considerations, such as particular goals (e.g., "robotics" or "machine learning"), the use of particular tools ("logic" or "neural networks"), or deep philosophical differences.\n\nThe traditional problems of AI research include reasoning, knowledge representation, planning, learning, natural language processing, perception, and the ability to move and manipulate objects. General intelligence is still among the field\'s long-term goals.',
        },
        {
          id: "2",
          title: "Machine Learning Fundamentals",
          source: "Data Science Weekly",
          excerpt:
            "Machine Learning is a subset of AI that provides systems the ability to automatically learn and improve from experience without being explicitly programmed.",
          content:
            "Machine Learning is a subset of Artificial Intelligence that provides systems the ability to automatically learn and improve from experience without being explicitly programmed. It focuses on the development of computer programs that can access data and use it to learn for themselves.\n\nThe process of learning begins with observations or data, such as examples, direct experience, or instruction, in order to look for patterns in data and make better decisions in the future based on the examples that we provide. The primary aim is to allow the computers to learn automatically without human intervention or assistance and adjust actions accordingly.\n\nMachine Learning algorithms are often categorized as supervised (using labeled training data), unsupervised (using unlabeled training data), or reinforcement learning (learning through trial and error with rewards and penalties).",
        },
        {
          id: "3",
          title: "Deep Learning and Neural Networks",
          source: "AI Research Institute",
          excerpt:
            "Deep Learning is a subfield of machine learning concerned with algorithms inspired by the structure and function of the brain called artificial neural networks.",
          content:
            'Deep Learning is a subfield of machine learning concerned with algorithms inspired by the structure and function of the brain called artificial neural networks. Deep learning is part of a broader family of machine learning methods based on artificial neural networks with representation learning.\n\nDeep learning architectures such as deep neural networks, deep belief networks, recurrent neural networks, and convolutional neural networks have been applied to fields including computer vision, speech recognition, natural language processing, audio recognition, social network filtering, machine translation, bioinformatics, drug design, medical image analysis, material inspection, and board game programs, where they have produced results comparable to and in some cases surpassing human expert performance.\n\nNeural networks are computing systems vaguely inspired by the biological neural networks that constitute animal brains. Such systems "learn" to perform tasks by considering examples, generally without being programmed with task-specific rules.',
        },
      ])
      setIsSearching(false)
    }, 1500)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const handleSelectContent = (content: string) => {
    setSelectedContent(content)
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex gap-2">
            <Input
              placeholder="Search for research materials..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <Button onClick={handleSearch} disabled={isSearching}>
              {isSearching ? "Searching..." : "Search"}
            </Button>
          </div>

          {searchResults.length > 0 && (
            <Tabs defaultValue="results">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="results">
                  <Search className="h-4 w-4 mr-2" />
                  Search Results
                </TabsTrigger>
                <TabsTrigger value="preview">
                  <FileText className="h-4 w-4 mr-2" />
                  Content Preview
                </TabsTrigger>
              </TabsList>

              <TabsContent value="results">
                <ScrollArea className="h-[400px]">
                  <div className="space-y-4 p-2">
                    {searchResults.map((result) => (
                      <div
                        key={result.id}
                        className="p-4 border rounded-lg cursor-pointer hover:bg-muted transition-colors"
                        onClick={() => handleSelectContent(result.content)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">{result.title}</h3>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation()
                              onAddToLesson(result.content)
                            }}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="text-sm text-muted-foreground mb-2">Source: {result.source}</div>
                        <p className="text-sm">{result.excerpt}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="preview">
                <ScrollArea className="h-[400px] p-4 border rounded-lg">
                  {selectedContent ? (
                    <div className="space-y-4">
                      <div className="prose dark:prose-invert max-w-none">
                        {selectedContent.split("\n\n").map((paragraph, index) => (
                          <p key={index}>{paragraph}</p>
                        ))}
                      </div>
                      <Button className="mt-4" onClick={() => onAddToLesson(selectedContent)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add to Lesson
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                      <BookOpen className="h-12 w-12 mb-4" />
                      <p>Select a search result to preview its content</p>
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          )}

          {searchResults.length === 0 && !isSearching && (
            <div className="h-[500px] overflow-y-auto border rounded-lg p-6 bg-card">
              <div className="prose dark:prose-invert max-w-none">
                <h1 className="text-2xl font-bold border-b pb-2 mb-6">Course Research & Outline Document</h1>

                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
                    H
                  </div>
                  <p className="italic text-muted-foreground">
                    This document will be populated based on your voice interactions with Hume EVI
                  </p>
                </div>

                <div className="space-y-6">
                  <section>
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-sm">
                        1
                      </span>
                      Research Phase
                    </h2>
                    <div className="pl-8 border-l-2 border-muted mt-2 space-y-2">
                      <p className="text-muted-foreground">Use the search bar above to research your course topic</p>
                      <p className="text-muted-foreground">
                        Hume will analyze your voice queries and compile relevant information
                      </p>
                      <div className="bg-muted p-3 rounded-md italic">
                        "Tell me about the fundamentals of artificial intelligence..."
                      </div>
                      <div className="pl-4 border-l-2 border-primary/30 mt-2">
                        <p className="text-sm">Research findings will appear here...</p>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-sm">
                        2
                      </span>
                      Course Outline
                    </h2>
                    <div className="pl-8 border-l-2 border-muted mt-2 space-y-2">
                      <p className="text-muted-foreground">
                        Based on your research and voice responses, Hume will generate a course outline
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-secondary/20 text-secondary-foreground text-xs">
                            M1
                          </span>
                          <p className="font-medium">Module 1: Introduction to [Topic]</p>
                        </div>
                        <div className="pl-7 space-y-1">
                          <p className="text-sm flex items-center gap-1">
                            <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-muted text-muted-foreground text-xs">
                              L1
                            </span>
                            Lesson 1.1: Overview of [Topic]
                          </p>
                          <p className="text-sm flex items-center gap-1">
                            <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-muted text-muted-foreground text-xs">
                              L2
                            </span>
                            Lesson 1.2: Key Concepts
                          </p>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-sm">
                        3
                      </span>
                      Content Generation
                    </h2>
                    <div className="pl-8 border-l-2 border-muted mt-2">
                      <p className="text-muted-foreground">
                        Hume will help generate content for each lesson based on research
                      </p>
                      <div className="bg-muted p-3 rounded-md mt-2 italic">
                        "Generate an introduction for the first lesson..."
                      </div>
                      <div className="pl-4 border-l-2 border-primary/30 mt-2">
                        <p className="text-sm">Generated content will appear here...</p>
                      </div>
                    </div>
                  </section>
                </div>

                <div className="mt-8 p-4 bg-muted rounded-lg">
                  <h3 className="font-medium mb-2">How to use this document:</h3>
                  <ol className="list-decimal pl-5 space-y-1">
                    <li>Enable voice assistant mode by clicking "Use Voice Assistant" at the top</li>
                    <li>Speak naturally to Hume about your course topic and goals</li>
                    <li>Research relevant topics using the search bar above</li>
                    <li>Review the generated outline and content</li>
                    <li>Edit and refine the course structure as needed</li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          {isSearching && (
            <div className="flex flex-col items-center justify-center h-[400px]">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              <p className="mt-4 text-muted-foreground">Searching for relevant materials...</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

