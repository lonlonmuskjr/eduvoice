import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"

const featuredCourses = [
  {
    id: 1,
    title: "Introduction to AI and Machine Learning",
    category: "Technology",
    image: "/placeholder.svg?height=400&width=600",
    instructor: "Dr. Sarah Johnson",
    level: "Beginner",
  },
  {
    id: 2,
    title: "Advanced Web Development with Next.js",
    category: "Programming",
    image: "/placeholder.svg?height=400&width=600",
    instructor: "Michael Chen",
    level: "Intermediate",
  },
  {
    id: 3,
    title: "The Science of Emotional Intelligence",
    category: "Psychology",
    image: "/placeholder.svg?height=400&width=600",
    instructor: "Dr. Emily Rodriguez",
    level: "All Levels",
  },
]

export function CourseShowcase() {
  return (
    <section className="py-20">
      <div className="flex justify-between items-center mb-12">
        <h2 className="text-3xl font-bold">Featured Courses</h2>
        <Link href="/courses" className="text-primary hover:underline">
          View All Courses
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {featuredCourses.map((course) => (
          <Card key={course.id} className="overflow-hidden">
            <div className="relative h-48 w-full">
              <Image src={course.image || "/placeholder.svg"} alt={course.title} fill className="object-cover" />
            </div>
            <CardHeader>
              <div className="flex justify-between items-start">
                <Badge>{course.category}</Badge>
                <Badge variant="outline">{course.level}</Badge>
              </div>
              <CardTitle className="mt-2">{course.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Instructor: {course.instructor}</p>
            </CardContent>
            <CardFooter>
              <Link href={`/courses/${course.id}`} className="w-full">
                <div className="w-full bg-primary text-primary-foreground py-2 rounded text-center hover:bg-primary/90 transition-colors">
                  View Course
                </div>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  )
}

