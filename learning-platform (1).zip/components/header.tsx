"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "./mode-toggle"
import { useState } from "react"
import { Menu, X, Settings } from "lucide-react"
import { VoiceAssistantButton } from "./voice-assistant-button"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold">
          EduVoice
        </Link>

        <div className="hidden md:flex items-center space-x-6">
          <nav className="flex items-center space-x-6">
            <Link href="/courses" className="hover:text-primary transition-colors">
              Courses
            </Link>
            <Link href="/research" className="hover:text-primary transition-colors">
              Research
            </Link>
            <Link href="/create" className="hover:text-primary transition-colors">
              Create
            </Link>
            <Link href="/community" className="hover:text-primary transition-colors">
              Community
            </Link>
          </nav>

          <div className="flex items-center space-x-3">
            <VoiceAssistantButton />
            <Link href="/settings">
              <Button variant="ghost" size="icon">
                <Settings className="h-5 w-5" />
                <span className="sr-only">Settings</span>
              </Button>
            </Link>
            <ModeToggle />
            <Button asChild size="sm">
              <Link href="/login">Sign In</Link>
            </Button>
          </div>
        </div>

        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="md:hidden px-4 py-4 border-t">
          <nav className="flex flex-col space-y-4">
            <Link href="/courses" className="hover:text-primary transition-colors">
              Courses
            </Link>
            <Link href="/research" className="hover:text-primary transition-colors">
              Research
            </Link>
            <Link href="/create" className="hover:text-primary transition-colors">
              Create
            </Link>
            <Link href="/community" className="hover:text-primary transition-colors">
              Community
            </Link>
            <Link href="/settings" className="hover:text-primary transition-colors">
              Settings
            </Link>
            <div className="flex items-center space-x-3 pt-2">
              <VoiceAssistantButton />
              <ModeToggle />
              <Button asChild size="sm">
                <Link href="/login">Sign In</Link>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}

