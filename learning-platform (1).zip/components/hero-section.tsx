import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="py-20 flex flex-col md:flex-row items-center gap-12">
      <div className="flex-1 space-y-6">
        <h1 className="text-4xl md:text-6xl font-bold leading-tight">
          Learn with the Power of <span className="text-primary">Voice AI</span> and{" "}
          <span className="text-primary">Emotional Intelligence</span>
        </h1>
        <p className="text-xl text-muted-foreground">
          Transform your learning experience with our AI-powered platform that adapts to your emotional cues and
          responds to your voice commands.
        </p>
        <div className="flex flex-wrap gap-4">
          <Button asChild size="lg">
            <Link href="/courses">Start Learning</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/demo">See Demo</Link>
          </Button>
        </div>
      </div>
      <div className="flex-1 relative h-[400px] w-full rounded-lg overflow-hidden">
        <Image
          src="/placeholder.svg?height=800&width=800"
          alt="AI-powered learning platform"
          fill
          className="object-cover"
        />
      </div>
    </section>
  )
}

