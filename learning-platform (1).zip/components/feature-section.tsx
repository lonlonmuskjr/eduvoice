import { Mic, BookOpen, PenTool, Search, Heart, Lightbulb } from "lucide-react"

const features = [
  {
    icon: <Mic className="h-10 w-10 text-primary" />,
    title: "Voice-Powered Learning",
    description: "Interact with lessons using natural voice commands and receive personalized responses.",
  },
  {
    icon: <Heart className="h-10 w-10 text-primary" />,
    title: "Emotional Intelligence",
    description: "Our platform adapts to your emotional cues to provide the most effective learning experience.",
  },
  {
    icon: <BookOpen className="h-10 w-10 text-primary" />,
    title: "Comprehensive Courses",
    description: "Access a wide range of courses designed by experts in various fields.",
  },
  {
    icon: <PenTool className="h-10 w-10 text-primary" />,
    title: "Course Creation",
    description: "Create and publish your own courses with our intuitive course builder.",
  },
  {
    icon: <Search className="h-10 w-10 text-primary" />,
    title: "AI Research Assistant",
    description: "Get instant answers to your questions with citations from reliable sources.",
  },
  {
    icon: <Lightbulb className="h-10 w-10 text-primary" />,
    title: "Personalized Learning",
    description: "Receive customized learning paths based on your progress and preferences.",
  },
]

export function FeatureSection() {
  return (
    <section className="py-20">
      <h2 className="text-3xl font-bold text-center mb-12">Powerful Features for Enhanced Learning</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div key={index} className="p-6 border rounded-lg hover:shadow-md transition-shadow">
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-muted-foreground">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

