"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Mic } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { VoiceAssistant } from "./voice-assistant"

export function VoiceAssistantButton() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <Mic className="h-[1.2rem] w-[1.2rem]" />
          <span className="sr-only">Voice Assistant</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Voice Assistant</DialogTitle>
          <DialogDescription>Ask me anything about courses, research, or navigation.</DialogDescription>
        </DialogHeader>
        <VoiceAssistant onClose={() => setIsOpen(false)} />
      </DialogContent>
    </Dialog>
  )
}

