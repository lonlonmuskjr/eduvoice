"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Trash2 } from "lucide-react"
import { ResearchAssistant } from "./research-assistant"

interface Module {
  id: string
  title: string
  lessons: Lesson[]
}

interface Lesson {
  id: string
  title: string
  content: string
  type: "video" | "text" | "quiz"
}

interface CourseCreatorProps {
  initialData?: {
    title: string
    description: string
    category: string
    level: string
    modules: Module[]
  }
}

export function CourseCreator({ initialData }: CourseCreatorProps) {
  const [courseTitle, setCourseTitle] = useState(initialData?.title || "")
  const [courseDescription, setCourseDescription] = useState(initialData?.description || "")
  const [courseCategory, setCourseCategory] = useState(initialData?.category || "")
  const [courseLevel, setCourseLevel] = useState(initialData?.level || "")
  const [modules, setModules] = useState<Module[]>(
    initialData?.modules || [
      {
        id: "1",
        title: "Introduction",
        lessons: [
          {
            id: "1",
            title: "Welcome to the Course",
            content: "",
            type: "text",
          },
        ],
      },
    ],
  )
  const [activeTab, setActiveTab] = useState("details")
  const [activeModuleId, setActiveModuleId] = useState("1")
  const [activeLessonId, setActiveLessonId] = useState("1")

  const addModule = () => {
    const newModule: Module = {
      id: Date.now().toString(),
      title: `New Module`,
      lessons: [],
    }
    setModules([...modules, newModule])
    setActiveModuleId(newModule.id)
  }

  const addLesson = (moduleId: string) => {
    const newLesson: Lesson = {
      id: Date.now().toString(),
      title: "New Lesson",
      content: "",
      type: "text",
    }

    setModules(
      modules.map((module) => {
        if (module.id === moduleId) {
          return {
            ...module,
            lessons: [...module.lessons, newLesson],
          }
        }
        return module
      }),
    )

    setActiveLessonId(newLesson.id)
  }

  const updateModuleTitle = (moduleId: string, title: string) => {
    setModules(modules.map((module) => (module.id === moduleId ? { ...module, title } : module)))
  }

  const updateLesson = (moduleId: string, lessonId: string, updates: Partial<Lesson>) => {
    setModules(
      modules.map((module) => {
        if (module.id === moduleId) {
          return {
            ...module,
            lessons: module.lessons.map((lesson) => (lesson.id === lessonId ? { ...lesson, ...updates } : lesson)),
          }
        }
        return module
      }),
    )
  }

  const deleteModule = (moduleId: string) => {
    setModules(modules.filter((module) => module.id !== moduleId))
    if (activeModuleId === moduleId && modules.length > 1) {
      setActiveModuleId(modules[0].id === moduleId ? modules[1].id : modules[0].id)
    }
  }

  const deleteLesson = (moduleId: string, lessonId: string) => {
    setModules(
      modules.map((module) => {
        if (module.id === moduleId) {
          const updatedLessons = module.lessons.filter((lesson) => lesson.id !== lessonId)
          return {
            ...module,
            lessons: updatedLessons,
          }
        }
        return module
      }),
    )

    const currentModule = modules.find((m) => m.id === moduleId)
    if (currentModule && activeLessonId === lessonId && currentModule.lessons.length > 1) {
      const lessonIndex = currentModule.lessons.findIndex((l) => l.id === lessonId)
      const newLessonId = lessonIndex === 0 ? currentModule.lessons[1].id : currentModule.lessons[lessonIndex - 1].id
      setActiveLessonId(newLessonId)
    }
  }

  const getActiveModule = () => modules.find((m) => m.id === activeModuleId)
  const getActiveLesson = () => {
    const module = getActiveModule()
    return module?.lessons.find((l) => l.id === activeLessonId)
  }

  return (
    <div className="space-y-8">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="details">Course Details</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="research">Research Assistant</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Course Information</CardTitle>
              <CardDescription>Provide the basic details about your course.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Course Title</Label>
                <Input
                  id="title"
                  value={courseTitle}
                  onChange={(e) => setCourseTitle(e.target.value)}
                  placeholder="e.g., Introduction to Machine Learning"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Course Description</Label>
                <Textarea
                  id="description"
                  value={courseDescription}
                  onChange={(e) => setCourseDescription(e.target.value)}
                  placeholder="Provide a detailed description of your course"
                  rows={5}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={courseCategory} onValueChange={setCourseCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="business">Business</SelectItem>
                      <SelectItem value="design">Design</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="personal-development">Personal Development</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="level">Level</Label>
                  <Select value={courseLevel} onValueChange={setCourseLevel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                      <SelectItem value="all-levels">All Levels</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={() => setActiveTab("content")}>Continue to Content</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="content">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Course Structure</CardTitle>
                <CardDescription>Organize your course into modules and lessons.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {modules.map((module) => (
                  <div key={module.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div
                        className={`font-medium cursor-pointer ${activeModuleId === module.id ? "text-primary" : ""}`}
                        onClick={() => setActiveModuleId(module.id)}
                      >
                        {module.title}
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => deleteModule(module.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="pl-4 space-y-1">
                      {module.lessons.map((lesson) => (
                        <div
                          key={lesson.id}
                          className={`text-sm cursor-pointer flex items-center justify-between ${
                            activeModuleId === module.id && activeLessonId === lesson.id
                              ? "text-primary"
                              : "text-muted-foreground"
                          }`}
                          onClick={() => {
                            setActiveModuleId(module.id)
                            setActiveLessonId(lesson.id)
                          }}
                        >
                          <span>{lesson.title}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteLesson(module.id, lesson.id)
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center text-xs"
                      onClick={() => addLesson(module.id)}
                    >
                      <PlusCircle className="h-3 w-3 mr-1" />
                      Add Lesson
                    </Button>
                  </div>
                ))}

                <Button variant="outline" className="w-full" onClick={addModule}>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Module
                </Button>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>
                  {getActiveModule()?.title || "Module"} - {getActiveLesson()?.title || "Lesson"}
                </CardTitle>
                <CardDescription>Edit your lesson content here.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {getActiveModule() && getActiveLesson() ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="lessonTitle">Lesson Title</Label>
                      <Input
                        id="lessonTitle"
                        value={getActiveLesson()?.title || ""}
                        onChange={(e) => updateLesson(activeModuleId, activeLessonId, { title: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lessonType">Lesson Type</Label>
                      <Select
                        value={getActiveLesson()?.type || "text"}
                        onValueChange={(value) =>
                          updateLesson(activeModuleId, activeLessonId, { type: value as "text" | "video" | "quiz" })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="text">Text</SelectItem>
                          <SelectItem value="video">Video</SelectItem>
                          <SelectItem value="quiz">Quiz</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lessonContent">Content</Label>
                      <Textarea
                        id="lessonContent"
                        value={getActiveLesson()?.content || ""}
                        onChange={(e) => updateLesson(activeModuleId, activeLessonId, { content: e.target.value })}
                        rows={10}
                      />
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    Select or create a module and lesson to edit content.
                  </div>
                )}
              </CardContent>
              <CardFooter className="justify-between">
                <Button variant="outline" onClick={() => setActiveTab("details")}>
                  Back to Details
                </Button>
                <Button onClick={() => setActiveTab("research")}>Research Assistant</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="research">
          <ResearchAssistant
            onAddToLesson={(content) => {
              if (getActiveModule() && getActiveLesson()) {
                const currentContent = getActiveLesson()?.content || ""
                updateLesson(activeModuleId, activeLessonId, { content: currentContent + "\n\n" + content })
                setActiveTab("content")
              }
            }}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

