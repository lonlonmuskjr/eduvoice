"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Mic, MicOff, Send, AlertCircle } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from "next/link"

interface Message {
  role: "user" | "assistant"
  content: string
  emotion?: string
}

interface VoiceAssistantProps {
  onClose: () => void
}

export function VoiceAssistant({ onClose }: VoiceAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hello! How can I help you with your learning journey today?" },
  ])
  const [input, setInput] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [humeApiKey, setHumeApiKey] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Load Hume API key on component mount
  useEffect(() => {
    const apiKey = localStorage.getItem("humeApiKey")
    setHumeApiKey(apiKey)
  }, [])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Simulate voice recognition
  const toggleListening = () => {
    if (!humeApiKey) {
      return
    }

    if (isListening) {
      setIsListening(false)
      // In a real implementation, you would stop the voice recognition here
    } else {
      setIsListening(true)
      // In a real implementation, you would start the voice recognition here
      // For demo purposes, we'll simulate receiving voice input after a delay
      setTimeout(() => {
        setInput("Can you recommend some courses on artificial intelligence?")
        setIsListening(false)
      }, 2000)
    }
  }

  const handleSendMessage = async () => {
    if (!input.trim() || isProcessing) return

    const userMessage: Message = { role: "user", content: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsProcessing(true)

    // In a real implementation, you would call the Hume API here
    // For demo purposes, we'll simulate a response
    setTimeout(() => {
      const assistantMessage: Message = {
        role: "assistant",
        content:
          'I can recommend several excellent AI courses. Our most popular ones are "Introduction to AI and Machine Learning" for beginners, "Deep Learning Fundamentals" for intermediate learners, and "Advanced Neural Networks" for those with prior experience. Would you like more details about any of these?',
        emotion: "helpful",
      }
      setMessages((prev) => [...prev, assistantMessage])
      setIsProcessing(false)
    }, 1500)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="flex flex-col h-[500px]">
      {!humeApiKey && (
        <Alert className="mb-4" variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>API Key Missing</AlertTitle>
          <AlertDescription>
            Please add your Hume API key in the{" "}
            <Link href="/settings" className="underline">
              settings
            </Link>{" "}
            to enable voice interactions.
          </AlertDescription>
        </Alert>
      )}

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message, index) => (
            <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`flex ${message.role === "user" ? "flex-row-reverse" : "flex-row"} gap-2 max-w-[80%]`}>
                {message.role === "assistant" && (
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" />
                    <AvatarFallback>AI</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`p-3 rounded-lg ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  {message.content}
                </div>
                {message.role === "user" && (
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" />
                    <AvatarFallback>You</AvatarFallback>
                  </Avatar>
                )}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message or press the mic to speak..."
            className="min-h-[60px]"
            disabled={isListening}
          />
          <div className="flex flex-col gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={toggleListening}
              className={isListening ? "bg-red-100 dark:bg-red-900" : ""}
              disabled={!humeApiKey}
            >
              {isListening ? <MicOff /> : <Mic />}
            </Button>
            <Button size="icon" onClick={handleSendMessage} disabled={!input.trim() || isProcessing}>
              <Send />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

